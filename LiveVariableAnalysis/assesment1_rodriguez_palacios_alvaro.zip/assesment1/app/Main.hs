module Main where

import Lib (mainLibFn)

main :: IO ()
main = do
    mainLibFn
